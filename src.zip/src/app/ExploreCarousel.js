"use client";
import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Image from "next/image";
import PowerMiles_Card from "./images/PowerMiles_Card.png";
import selfi from "./images/selfi.png";
import tiga from "./images/tiga.png";



function ExploreCarousel() {




    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 3, // Show 3 slides on larger screens
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 5000,
        arrows: true,

        responsive: [
            {
                breakpoint: 1024, // Tablets (max-width: 1024px)
                settings: {
                    slidesToShow: 2, // Show 2 slides on tablets
                },
            },
            {
                breakpoint: 600, // Mobile (max-width: 600px)
                settings: {
                    slidesToShow: 1, // Show 1 slide on mobile
                },
            },
        ],
    };




 
return (
    <div  >
        {/* explore crdit card */}
        <div className="flex justify-center my-14">
            <div className="container">
                <div className=" ">
                    <Slider {...settings}>
                        <div className="px-5" >
                            <div className="xplore-box c1">
                                <Image className="img-fluid" src={PowerMiles_Card} alt="" />
                                <div className="" >
                                    <div className="xplore-txt ct1">
                                        <p>PowerMiles Credit Card </p>
                                        <p>  Earn miles on every spend & enjoy airport lounge access for seamless travel.</p>
                                    </div>
                                    <div className="xplore-txt-card ct2">
                                        <p>Features</p>
                                        <ul className="  list-disc">
                                            <li>Earn travel miles on every domestic and international spend.</li>
                                            <li>Complimentary airport lounge access at major airports.</li>
                                            <li>Fuel surcharge waiver at select fuel stations across India.</li>
                                            <li>Zero liability on lost card for unauthorized transactions reported in time.</li>
                                            <li>Travel insurance coverage for added security during trips.</li>
                                            <li>Accelerated rewards on travel, hotel, and airline bookings.</li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="xplore-btn   ">
                                    <button className="">Apply Now</button>
                                    <button className="">Know More</button>
                                </div>

                            </div>
                        </div>
                        <div className="px-5" >
                            <div className="xplore-box c2">
                                <Image className="img-fluid" src={selfi} alt="" />
                                <div className="xplore-txt ct2">
                                    <p>Selfe Credit Card </p>
                                    <p> Apply online instantly & experience 100% digital banking convenience.</p>
                                </div>
                                <div className="xplore-txt-card ct2">
                                    <p>Features</p>
                                    <ul className="  list-disc">
                                        <li>Instant online approval without physical documentation.</li>
                                        <li>No branch visit required – complete process online.</li>
                                        <li>Cashback on digital transactions including utility bill payments.</li>
                                        <li>Smart spend analyzer to track and manage your expenses.</li>
                                        <li>Enhanced security with two-factor authentication and dynamic CVV.</li>
                                    </ul>
                                </div>
                                <div className="xplore-btn">
                                    <button className="">Apply Now</button>
                                    <button className="">Know More</button>
                                </div>
                            </div>
                        </div>
                        <div className="px-5">
                            <div className="xplore-box c3">
                                <Image className="img-fluid" src={tiga} alt="" />
                                <div className="xplore-txt ct3">
                                    <p>PowerMiles Credit Card </p>
                                    <p>  Earn miles on every spend & enjoy airport lounge access for seamless travel.</p>
                                </div>
                                <div className="xplore-txt-card ct3">
                                    <p style={{ color: "#000080" }}>Features</p>
                                    <ul className="list-inside list-disc">
                                        <li>Up to 5% cashback on groceries, dining, and bill payments.</li>
                                        <li>Exclusive dining and entertainment offers at partner outlets.</li>
                                        <li>Flexible EMI options to convert large purchases into easy installments.</li>
                                        <li>Contactless payments for secure and convenient transactions.</li>
                                        <li>Low forex markup on international spends.</li>
                                        <li>Purchase protection insurance to safeguard your purchases.</li>
                                    </ul>
                                </div>
                                <div className="xplore-btn ctb3">
                                    <button className="">Apply Now</button>
                                    <button className="">Know More</button>
                                </div>
                            </div>
                        </div>
                    </Slider>
                </div>
                <div className="text-center mt-14">
                    <p className="why-choose">How It Works?</p>
                </div>
            </div>
        </div>


    </div>
)
}

export default ExploreCarousel
