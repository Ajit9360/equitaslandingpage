(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_af6fddbc.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_af6fddbc.js",
  "chunks": [
    "static/chunks/node_modules_f6691a92._.js",
    "static/chunks/src_app_552215ae._.js",
    "static/chunks/node_modules_slick-carousel_slick_eab2732a._.css"
  ],
  "source": "dynamic"
});
