(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_d51f3164.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_d51f3164.js",
  "chunks": [
    "static/chunks/node_modules_f6691a92._.js",
    "static/chunks/src_app_b914f5e8._.js",
    "static/chunks/node_modules_slick-carousel_slick_eab2732a._.css"
  ],
  "source": "dynamic"
});
