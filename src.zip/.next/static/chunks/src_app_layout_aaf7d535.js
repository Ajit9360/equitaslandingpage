(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_aaf7d535.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_aaf7d535.js",
  "chunks": [
    "static/chunks/[root of the server]__dadaf8f7._.css"
  ],
  "source": "dynamic"
});
